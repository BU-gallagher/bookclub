package com.bookclub.web;

/*
Assigment 4.2 #9
Update the WishlistController 
Additional requirements 
a. Add a property named wishlistDao of type WishlistDao and instantiate an instance of 
    the MongoWishlistDao(). 
b. Create a private method named setWishlistDao that accepts a WishlistDao object as it’s parameter and 
    in the body assign it to this.wishlistDao.  Set the methods decorator to @Autowired.  
c. Update the code in the showWishlist() method to call the wishlistDao object. 
d. Update the code in the addWishlistItem() method to call the wishlistDao.add() method.  


Saved inside web folder -- Mark Gallagher, 2026

Krasso, K. (2026). CIS 530 Server-Side Development. Bellevue University, all rights reserved.
Supplemental syntax created by ChatGPT, 2026
Modified by Mark Gallagher, 2026
*/

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bookclub.model.WishlistItem;
import com.bookclub.service.dao.WishlistDao;

import jakarta.validation.Valid;


@Controller
@RequestMapping("/wishlist")
public class WishlistController {

    private WishlistDao wishlistDao;
    //private WishlistDao wishlistDao = new MongoWishlistDao();

    @Autowired
    public void setWishlistDao(WishlistDao wishlistDao) {
        this.wishlistDao = wishlistDao;
    }

    @RequestMapping(method = RequestMethod.GET)
    public String showWishlist(Model model) {
        List<WishlistItem> wishlist = wishlistDao.list();
        model.addAttribute("wishlist", wishlist);
        return "wishlist/list";
    }

    @RequestMapping(value = "/new", method = RequestMethod.GET)
    public String wishlistForm(Model model) {
        model.addAttribute("wishlistItem", new WishlistItem());
        return "wishlist/new";
    }

    @RequestMapping(method = RequestMethod.POST)
    public String addWishlistItem(@Valid WishlistItem wishlistItem, BindingResult bindingResult) {
        System.out.println(wishlistItem.toString());

        System.out.println(bindingResult.getAllErrors());

        if (bindingResult.hasErrors()) {
            return "wishlist/new";
        }
        wishlistDao.add(wishlistItem);
        
        return "redirect:/wishlist";
    }
}
